from ultralytics import YOLO
import cv2
import os

def crop_main_persons_in_folder(input_folder, output_folder, model_path="yolov8n.pt"):
    # Load YOLO model (pretrained weights for object detection)
    model = YOLO(model_path)

    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Iterate through all files in the input folder
    for image_name in os.listdir(input_folder):
        image_path = os.path.join(input_folder, image_name)
        
        # Check if the file is an image (e.g., jpg, png, etc.)
        if image_name.lower().endswith(('.png', '.jpg', '.jpeg')):
            print(f"Processing image: {image_name}")
            
            # Load the input image
            img = cv2.imread(image_path)
            if img is None:
                print(f"Error: Unable to load image {image_path}")
                continue
            
            # Get image dimensions
            img_height, img_width, _ = img.shape
            img_center = (img_width / 2, img_height / 2)
            
            # Run human detection
            results = model(image_path)
            
            # Extract bounding boxes for humans (class 0 = 'person')
            detections = results[0].boxes
            human_boxes = [
                (box.xyxy[0].tolist(), box.conf[0].item())
                for box in detections if int(box.cls) == 0
            ]
            
            if not human_boxes:
                print(f"No human detected in {image_name}.")
                continue
            
            # Select the main person: largest bounding box (area-based)
            largest_box = None
            largest_area = 0
            for box, confidence in human_boxes:
                x1, y1, x2, y2 = map(int, box)
                width, height = x2 - x1, y2 - y1
                area = width * height
                if area > largest_area:
                    largest_area = area
                    largest_box = (x1, y1, x2, y2)

            if largest_box is None:
                print(f"No valid bounding box found for humans in {image_name}.")
                continue

            # Crop the main person
            x1, y1, x2, y2 = largest_box
            cropped = img[y1:y2, x1:x2]
            
            # Save the cropped image
            cropped_image_name = f"{os.path.splitext(image_name)[0]}_main_person.jpg"
            output_path = os.path.join(output_folder, cropped_image_name)
            cv2.imwrite(output_path, cropped)
            print(f"Main person cropped and saved at: {output_path}")

# Input and output folders
input_folder = r"C:\Users\AjayKrishnan\OneDrive - ADA Global\Desktop\coplt\object_detection\cleaned_dataset\video_frames"  # Replace with your input folder containing images
output_folder = r"cropped_images"  # Replace with your desired output folder

# Run the function
crop_main_persons_in_folder(input_folder, output_folder)
