import pandas as pd
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.preprocessing import LabelEncoder
import h5py
from sklearn.feature_extraction.text import TfidfVectorizer
import warnings
warnings.filterwarnings('ignore')

from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout
from tensorflow.keras.utils import to_categorical

from flask import Flask, request, render_template_string, jsonify
import os
import pickle


encoder = pickle.load(open("encoder.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))
loaded_model = load_model('nn_model.h5')
# loaded_model = h5py.File('mytestfile.hdf5', 'r')

import string
def remove_punctuations(text):
    for punctuation in string.punctuation:
        text = text.replace(punctuation, '')
    return text
def preprocess(df):
    df = df.dropna()
    #lower
    df[0] = df[0].apply(lambda x: x.lower())
    # #punctuation
    df[0] = df[0].apply(remove_punctuations)
    wordnet = WordNetLemmatizer()
    stop = stopwords.words('english')
    df[0] = df[0].apply(lambda x: ' '.join([word for word in x.split() if word not in (stop)]))
    df[0] = df[0].apply(lambda x: wordnet.lemmatize(x))
    X = vectorizer.transform(df[0]).toarray()
    
    
    # y = encoder.transform(df[0])
    # y = to_categorical(y)
    return X


def prediction_function(X):
    prediction = loaded_model.predict(X.reshape(1,-1))
    return prediction






app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/')
def index():
    return render_template_string('''
    <!doctype html>
    <html lang="en">
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Upload CSV</title>
      </head>
      <body>
        <h1>Upload CSV File</h1>
        <form method="post" action="/ajay" enctype="multipart/form-data">
          <input type="file" name="file">
          <input type="submit" value="Upload">
        </form>
      </body>
    </html>
    ''')

@app.route('/ajay', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        response = {}
        ans = []
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)
        data = pd.read_csv(filepath, header=None, delimiter = '\n\n')
        print(data)
        X_test= preprocess(data)
        for i in range(len(X_test)):
            pred = prediction_function(X_test[i])
            # print(pred)
            ans.append(encoder.inverse_transform([np.argmax(pred[0])])[0])
        response['ans'] = ans
        # print(ans, y_test)
        return (response)
        # return data.to_html()

if __name__ == '__main__':
    app.run(debug=True)
