import streamlit as st
from PIL import Image
import numpy as np
import tensorflow as tf

model = tf.keras.models.load_model('my_model.h5', compile = False)


def predict_function(path, model):
    im = Image.open(path) 
    im = im.resize((200, 200), Image.LANCZOS)
    im = np.array(im)
    im_input = np.expand_dims(im, 0)
    pred = model.predict(im_input)
    result = np.argmax(pred)
    if result == 0:
        return "Potato___Early_blight"
    elif result == 1:
        return "Potato___Late_blight"
    else:
        return "Potato___healthy"




st.title("Potato Disease Predictor")

uploaded_file = st.file_uploader("Choose an image...", type="jpg")

if uploaded_file is not None:    
    # Display the uploaded image
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded Image.', use_column_width=True)
    
    # Predict button
    if st.button('Predict'):
        # Make prediction
        result = predict_function(uploaded_file, model)
        st.write(f"The predicted disease is: {result}")