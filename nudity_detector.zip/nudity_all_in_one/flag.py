import cv2
import os
import opennsfw2 as n2

def extract_frames(video_path, output_folder, interval=0.5):
    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)
    
    # Load the video
    video_capture = cv2.VideoCapture(video_path)
    
    if not video_capture.isOpened():
        print("Error: Unable to open video file.")
        return
    
    fps = int(video_capture.get(cv2.CAP_PROP_FPS))
    total_frames = int(video_capture.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = total_frames / fps
    
    # print(f"Video FPS: {fps}, Total Frames: {total_frames}, Duration: {duration}s")
    
    frame_count = 0
    saved_frames = 0

    while video_capture.isOpened():
        ret, frame = video_capture.read()
        if not ret:
            break
        
        # Save a frame every 'interval' seconds
        if frame_count % (fps * interval) == 0:
            frame_filename = os.path.join(output_folder, f"frame_{saved_frames:04d}.jpg")
            cv2.imwrite(frame_filename, frame)
            # print(f"Saved {frame_filename}")
            saved_frames += 1
        
        frame_count += 1
        
        # Stop if duration exceeds 30 seconds
        if frame_count > 30 * fps:
            break
    
    video_capture.release()
    print("Frames extraction completed.")


def percentage(folder_path):
    # Define the folder containing the images
    folder_path = folder_path
    prob_dict = {}
    # List all files in the folder
    image_files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

    # Iterate over all image files
    for image_file in image_files:
        # Construct the full file path
        image_handle = os.path.join(folder_path, image_file)
        
        # Predict NSFW probability for each image
        nsfw_probability = n2.predict_image(image_handle)

        prob_dict[image_handle] = nsfw_probability    
        # Print the result
        # print(f"NSFW probability for {image_file}: {nsfw_probability}")
    filtered_nsfw_dict = {image_name: prob for image_name, prob in prob_dict.items() if prob > 0.2}
    return len(filtered_nsfw_dict)*100/len(prob_dict)



folder_path = r"C:\Users\AjayKrishnan\OneDrive - ADA Global\Desktop\coplt\object_detection\cleaned_dataset\nudity\video_frames"

# Input: Path to the video file and output folder
video_file = r"C:\Users\AjayKrishnan\OneDrive - ADA Global\Desktop\coplt\object_detection\cleaned_dataset\nudity\sample-videos-hul\Tresemme - Disha - Poor.mp4"  # Replace with your video file
output_dir = "video_frames"

extract_frames(video_file, output_dir)
ans = percentage(folder_path)
print("Percetnage: ",ans)