import cv2
import os

def extract_frames(video_path, output_folder, interval=0.5):
    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)
    
    # Load the video
    video_capture = cv2.VideoCapture(video_path)
    
    if not video_capture.isOpened():
        print("Error: Unable to open video file.")
        return
    
    fps = int(video_capture.get(cv2.CAP_PROP_FPS))
    total_frames = int(video_capture.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = total_frames / fps
    
    print(f"Video FPS: {fps}, Total Frames: {total_frames}, Duration: {duration}s")
    
    frame_count = 0
    saved_frames = 0

    while video_capture.isOpened():
        ret, frame = video_capture.read()
        if not ret:
            break
        
        # Save a frame every 'interval' seconds
        if frame_count % (fps * interval) == 0:
            frame_filename = os.path.join(output_folder, f"frame_{saved_frames:04d}.jpg")
            cv2.imwrite(frame_filename, frame)
            print(f"Saved {frame_filename}")
            saved_frames += 1
        
        frame_count += 1
        
        # Stop if duration exceeds 30 seconds
        if frame_count > 30 * fps:
            break
    
    video_capture.release()
    print("Frames extraction completed.")

# Input: Path to the video file and output folder
video_file = r"C:\Users\AjayKrishnan\OneDrive - ADA Global\Desktop\coplt\object_detection\cleaned_dataset\nudity\sample-videos-hul\Video_nudity2.mp4"  # Replace with your video file
output_dir = "./video_frames"

extract_frames(video_file, output_dir)
