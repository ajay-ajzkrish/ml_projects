import streamlit as st
import pandas as pd
import ollama
import re
import ast
import io
import sys
import traceback
from contextlib import redirect_stdout
import matplotlib.pyplot as plt
import seaborn as sns
import uuid
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# App setup
st.set_page_config(page_title="Natural Language Data Analysis", layout="wide")
st.title("📊 Natural Language Data Analysis")
st.markdown("""
Upload a CSV file and ask questions about your data in plain English.
The app uses a local LLM (via Ollama) to generate and execute Pandas code securely.
""")

# Initialize session state
if 'df' not in st.session_state:
    st.session_state.df = None
if 'column_descriptions' not in st.session_state:
    st.session_state.column_descriptions = ""
if 'generated_code' not in st.session_state:
    st.session_state.generated_code = ""
if 'last_query' not in st.session_state:
    st.session_state.last_query = ""
if 'execution_result' not in st.session_state:
    st.session_state.execution_result = None
if 'error_message' not in st.session_state:
    st.session_state.error_message = ""

# Sidebar for settings
with st.sidebar:
    st.header("Settings")
    model_name = st.selectbox("LLM Model", ["llama2", "mistral", "gemma"], index=0)
    temperature = st.slider("Temperature", 0.0, 1.0, 0.2)
    safety_check = st.checkbox("Review code before execution", True)
    st.markdown("---")
    st.markdown("**How to use:**")
    st.markdown("""
    1. Upload a CSV file
    2. (Optional) Upload column descriptions
    3. Ask questions about your data
    4. Review & execute generated code
    5. Use 'Explain' to understand the code
    """)

# File upload section
with st.expander("📂 Upload Data", expanded=True):
    col1, col2 = st.columns(2)
    with col1:
        uploaded_csv = st.file_uploader("CSV File", type=['csv'])
    with col2:
        uploaded_desc = st.file_uploader("Column Descriptions (Optional)", type=['txt'])

# Process uploaded files
if uploaded_csv:
    try:
        st.session_state.df = pd.read_csv(uploaded_csv)
        st.success(f"Data loaded with {len(st.session_state.df)} rows and {len(st.session_state.df.columns)} columns")
        with st.expander("Show Data Preview"):
            st.dataframe(st.session_state.df.head(5))
        with st.expander("Show Column Info"):
            buffer = io.StringIO()
            st.session_state.df.info(buf=buffer)
            st.text(buffer.getvalue())
    except Exception as e:
        st.error(f"Error loading CSV: {str(e)}")
        logger.error(f"CSV loading error: {str(e)}")

if uploaded_desc:
    try:
        st.session_state.column_descriptions = uploaded_desc.read().decode("utf-8")
        st.success("Column descriptions loaded!")
        with st.expander("Show Column Descriptions"):
            st.text(st.session_state.column_descriptions)
    except Exception as e:
        st.error(f"Error loading descriptions: {str(e)}")
        logger.error(f"Description loading error: {str(e)}")

# Query section
with st.expander("💬 Ask About Your Data", expanded=True):
    query = st.text_area(
        "Enter your question (e.g., 'Show average sales by region' or 'Plot sales over time')",
        height=100,
        key="query_input"
    )
    col1, col2 = st.columns(2)
    with col1:
        submit_button = st.button("Submit Query")
    with col2:
        explain_button = st.button("Explain Code")

# Functions
def create_prompt(df, descriptions, query):
    return f"""
You are an expert data analyst. Generate safe and correct Pandas code to answer this query: "{query}"

### Data Info:
- Shape: {df.shape}
- Columns: {', '.join(df.columns)}
- Dtypes: {df.dtypes.to_string()}
- First 3 rows:
{df.head(3).to_string()}

### Column Descriptions:
{descriptions if descriptions else 'None provided'}

### Rules:
1. Use only pandas, numpy, matplotlib.pyplot, seaborn, and Python built-ins
2. The DataFrame is in variable 'df'
3. Return results in a variable named 'result' (DataFrame, Series, or plot)
4. For plots, use matplotlib or seaborn and save to 'plot.png'
5. Wrap code in ```python ```
6. Avoid file I/O operations except for saving plots
7. Do not use exec() or eval()
8. Handle potential errors with try-except

### Example:
Query: "Calculate average sales by region"
```python
try:
    result = df.groupby('region')['sales'].mean()
except KeyError as e:
    result = f"Error: Column not found - {{str(e)}}"
```
"""

def extract_code(text):
    pattern = r'```python\n(.*?)```'
    matches = re.findall(pattern, text, re.DOTALL)
    return matches[0].strip() if matches else None

def safe_execute_code(code, df):
    try:
        # Create a safe locals dict with only allowed modules
        safe_locals = {
            'df': df.copy(),  # Work on a copy to prevent modifications
            'pd': pd,
            'np': __import__('numpy'),
            'plt': plt,
            'sns': sns,
            'result': None
        }
        
        # Redirect stdout to capture print statements
        output = io.StringIO()
        with redirect_stdout(output):
            # Execute code in restricted environment
            exec(code, {'__builtins__': {}}, safe_locals)
        
        result = safe_locals.get('result')
        printed_output = output.getvalue()
        
        # Check for plot
        plot_path = 'plot.png'
        import os
        plot_exists = os.path.exists(plot_path)
        
        return {
            'result': result,
            'printed': printed_output,
            'plot': plot_path if plot_exists else None,
            'error': None
        }
    except Exception as e:
        return {
            'result': None,
            'printed': '',
            'plot': None,
            'error': f"Execution error: {str(e)}\n{traceback.format_exc()}"
        }

def explain_code(code, query):
    prompt = f"""
Explain this Pandas code generated for the query: "{query}"

### Code:
```python
{code}
```

Provide a clear, concise explanation of:
1. What the code does
2. Key operations and their purpose
3. The expected output format
"""
    try:
        response = ollama.generate(model=model_name, prompt=prompt, options={'temperature': 0.1})
        return response['response']
    except Exception as e:
        return f"Error generating explanation: {str(e)}"

# Handle query submission
if submit_button and query and st.session_state.df is not None:
    st.session_state.last_query = query
    try:
        # Generate code using Ollama
        prompt = create_prompt(st.session_state.df, st.session_state.column_descriptions, query)
        response = ollama.generate(model=model_name, prompt=prompt, options={'temperature': temperature})
        code = extract_code(response['response'])
        
        if not code:
            st.error("No valid Python code generated by the model.")
            logger.error("No valid code extracted from LLM response")
            st.session_state.error_message = "No valid Python code generated."
        else:
            st.session_state.generated_code = code
            st.session_state.error_message = ""
            
            # Show generated code
            st.subheader("Generated Code")
            st.code(code, language='python')
            
            # Execute code if not in safety check mode or if user confirms
            if not safety_check:
                execution_result = safe_execute_code(code, st.session_state.df)
                st.session_state.execution_result = execution_result
            else:
                if st.button("Execute Code"):
                    execution_result = safe_execute_code(code, st.session_state.df)
                    st.session_state.execution_result = execution_result
    except Exception as e:
        st.error(f"Error generating code: {str(e)}")
        logger.error(f"Code generation error: {str(e)}")
        st.session_state.error_message = str(e)

# Display execution results
if st.session_state.execution_result:
    result = st.session_state.execution_result
    
    st.subheader("Results")
    
    if result['error']:
        st.error(result['error'])
        logger.error(f"Execution error: {result['error']}")
    else:
        # Display DataFrame or Series
        if isinstance(result['result'], (pd.DataFrame, pd.Series)):
            st.dataframe(result['result'])
        elif result['result'] is not None:
            st.write(result['result'])
        
        # Display plot if exists
        if result['plot']:
            st.image(result['plot'])
        
        # Display printed output
        if result['printed']:
            st.text("Console Output:")
            st.text(result['printed'])

# Handle explain button
if explain_button and st.session_state.generated_code:
    st.subheader("Code Explanation")
    explanation = explain_code(st.session_state.generated_code, st.session_state.last_query)
    st.markdown(explanation)

# Error message display
if st.session_state.error_message:
    st.error(st.session_state.error_message)